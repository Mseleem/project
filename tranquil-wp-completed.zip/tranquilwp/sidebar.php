
<?php if ( is_active_sidebar( 'sidebar_blog' ) ) : ?>
<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
    <?php dynamic_sidebar( 'sidebar_blog' ); ?>
</div><!-- #primary-sidebar -->
<?php endif; ?>
      

